import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.*;

public class TopReviews extends Configured implements Tool {

    public static void main(String[] args) throws Exception {
        int res = ToolRunner.run(new Configuration(), new TopReviews(), args);
        System.exit(res);
    }

    @Override
    public int run(String[] args) throws Exception {
        Configuration conf = this.getConf();

        FileSystem fs = FileSystem.get(conf);
        Path tmpPath = new Path("./preF-output");

        Job jobA = Job.getInstance(conf, "Review Count");
        jobA.setJarByClass(this.getClass());

        jobA.setOutputKeyClass(Text.class);
        jobA.setOutputValueClass(IntWritable.class);

        jobA.setMapperClass(ReviewCountMap.class);
        jobA.setReducerClass(ReviewCountReduce.class);

        FileInputFormat.setInputPaths(jobA, new Path(args[0]));
        FileOutputFormat.setOutputPath(jobA, tmpPath);

        jobA.waitForCompletion(true);

        Job jobB = Job.getInstance(conf, "Top Reviews");
        jobB.setJarByClass(this.getClass());

        jobB.setOutputKeyClass(NullWritable.class);
        jobB.setOutputValueClass(Text.class);

        jobB.setMapperClass(TopReviewsMap.class);
        jobB.setReducerClass(TopReviewsReduce.class);

        jobB.setNumReduceTasks(1);

        FileInputFormat.setInputPaths(jobB, tmpPath);
        FileOutputFormat.setOutputPath(jobB, new Path(args[1]));

        return jobB.waitForCompletion(true) ? 0 : 1;
    }

    public static class ReviewCountMap extends Mapper<LongWritable, Text, Text, IntWritable> {
        private final List<String> stopWords = new ArrayList<>();
        private String delimiters;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            Configuration conf = context.getConfiguration();

            String stopWordsPath = conf.get("stopwords");
            String delimitersPath = conf.get("delimiters");

            this.stopWords.addAll(Arrays.asList(readHDFSFile(stopWordsPath, conf).split("\n")));
            this.delimiters = readHDFSFile(delimitersPath, conf);
        }

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            JSONObject obj = new JSONObject(value.toString());

            String business_id = obj.getString("business_id");
            int stars = obj.getInt("stars");
            String text = obj.getString("text").toLowerCase();

            int weight = stars - 3; // Convert original stars to range (-2 to 2)

            StringTokenizer tokenizer = new StringTokenizer(text, delimiters);
            int reviewLength = 0;
            while (tokenizer.hasMoreTokens()) {
                String token = tokenizer.nextToken().trim();
                if (!stopWords.contains(token)) {
                    reviewLength++;
                }
            }

            context.write(new Text(business_id), new IntWritable(weight * reviewLength));
        }
    }

    public static class ReviewCountReduce extends Reducer<Text, IntWritable, Text, DoubleWritable> {
        @Override
        public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            int totalScore = 0;
            int totalLength = 0;

            for (IntWritable value : values) {
                int weightedScore = value.get();
                totalScore += weightedScore;
                totalLength++;
            }

            double weightedAvgScore = (double) totalScore / totalLength;
            context.write(key, new DoubleWritable(weightedAvgScore));
        }
    }

    public static class TopReviewsMap extends Mapper<Object, Text, NullWritable, Text> {
        private final TreeSet<Pair<Double, String>> countToReviewMap = new TreeSet<>(Collections.reverseOrder());
        private int N;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            Configuration conf = context.getConfiguration();
            this.N = conf.getInt("N", 10);
        }

        @Override
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String[] tokens = value.toString().split("\\s+");
            String businessId = tokens[0];
            double weightedAvgScore = Double.parseDouble(tokens[1]);

            countToReviewMap.add(new Pair<>(weightedAvgScore, businessId));

            if (countToReviewMap.size() > N) {
                countToReviewMap.remove(countToReviewMap.last());
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            for (Pair<Double, String> item : countToReviewMap) {
                context.write(NullWritable.get(), new Text(item.second + "\t" + item.first));
            }
        }
    }

    public static class TopReviewsReduce extends Reducer<NullWritable, Text, Text, NullWritable> {
        private final TreeSet<Pair<Double, String>> countToReviewMap = new TreeSet<>(Collections.reverseOrder());
        private int N;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            Configuration conf = context.getConfiguration();
            this.N = conf.getInt("N", 10);
        }

        @Override
        public void reduce(NullWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            for (Text value : values) {
                String[] tokens = value.toString().split("\\s+");
                String businessId = tokens[0];
                double weightedAvgScore = Double.parseDouble(tokens[1]);

                countToReviewMap.add(new Pair<>(weightedAvgScore, businessId));

                if (countToReviewMap.size() > N) {
                    countToReviewMap.remove(countToReviewMap.last());
                }
            }

            for (Pair<Double, String> item : countToReviewMap) {
                context.write(new Text(item.second), NullWritable.get());
            }
        }
    }
}
