#!/usr/bin/env python
import sys
from pyspark import SparkConf, SparkContext

conf = SparkConf().setMaster("local").setAppName("OrphanPages")
conf.set("spark.driver.bindAddress", "127.0.0.1")
sc = SparkContext(conf=conf)

lines = sc.textFile(sys.argv[1], 1) 

#TODO
# linked_pages = lines.flatMap(lambda line: line.split()[1:])
# linked_pages = lines.flatMap(lambda line: line.split(":")[1].strip().split())
# page_ids = lines.map(lambda line: line.split()[0])
# orphan_pages = page_ids.subtract(linked_pages)
# sorted_orphan_pages = orphan_pages.sortBy(lambda x: x)
# Split each line by ":" and extract page ID
page_links = lines.map(lambda line: line.split(":")[0].strip())
linked_pages = lines.flatMap(lambda line: line.split(":")[1].strip().split())
linked_pages_unique = linked_pages.distinct()
linked_pages_all = linked_pages_unique.union(page_links)
orphans = page_links.subtract(linked_pages_all)
sorted_orphans = orphans.sortBy(lambda x: x)

output = open(sys.argv[2], "w")

#TODO
#write results to output file. Foramt for each line: (line + "\n")
for orphan_page in sorted_orphans.collect():
    output.write(f"{orphan_page}\n")

output.close()
sc.stop()

